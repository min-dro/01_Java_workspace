package com.kh.model.dao;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.kh.model.vo.Keyboard;

public class KeyboardDao { // 클래스 영역 시작
	
	public void saveFile(ArrayList<Keyboard> keyboardList) { // 메소드 영역 시작
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("keyboard.txt"))){
			
			oos.writeObject(keyboardList);
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	} // 메소드 영역 끝
	
	public ArrayList<Keyboard> loadFile() { // 메소드 영역 시작
		
		ArrayList<Keyboard> keyboardList = null;
		
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("keyboard.txt"))){
			
			keyboardList =  (ArrayList<Keyboard>) ois.readObject();
			
		} catch(EOFException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return keyboardList;
	} // 메소드 영역 끝
	
} // 클래스 영역 끝
